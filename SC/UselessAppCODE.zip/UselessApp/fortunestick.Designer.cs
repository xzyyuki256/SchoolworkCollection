﻿
namespace UselessApp
{
    partial class fortunestick
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.b_fortunestick = new System.Windows.Forms.Button();
            this.fs_result = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(60, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 340);
            this.label2.TabIndex = 1;
            // 
            // b_fortunestick
            // 
            this.b_fortunestick.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_fortunestick.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b_fortunestick.Location = new System.Drawing.Point(197, 230);
            this.b_fortunestick.Name = "b_fortunestick";
            this.b_fortunestick.Size = new System.Drawing.Size(102, 92);
            this.b_fortunestick.TabIndex = 2;
            this.b_fortunestick.Text = "求籤";
            this.b_fortunestick.UseVisualStyleBackColor = true;
            this.b_fortunestick.Click += new System.EventHandler(this.b_fortunestick_Click);
            // 
            // fs_result
            // 
            this.fs_result.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fs_result.BackColor = System.Drawing.Color.Red;
            this.fs_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fs_result.ForeColor = System.Drawing.Color.Snow;
            this.fs_result.Location = new System.Drawing.Point(60, 52);
            this.fs_result.Name = "fs_result";
            this.fs_result.Size = new System.Drawing.Size(75, 89);
            this.fs_result.TabIndex = 3;
            this.fs_result.Text = "結果";
            this.fs_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fortunestick
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 348);
            this.Controls.Add(this.fs_result);
            this.Controls.Add(this.b_fortunestick);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "fortunestick";
            this.Text = "fortunestick";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button b_fortunestick;
        private System.Windows.Forms.Label fs_result;
    }
}