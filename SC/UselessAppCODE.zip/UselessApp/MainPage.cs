﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UselessApp
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void b_about_Click(object sender, EventArgs e)
        {
            string about_msg = "This app contains useless functions and games. Just click which tools you want to use.\n\n" 
                                + "Made for school assignment, all things made by me.\n Upload to my github as record.";
            MessageBox.Show(about_msg, "About");
        }

        private void b_option_Click(object sender, EventArgs e)
        {
            var myForm = new options();
            myForm.Show();
        }

        private void b_bigclock_Click(object sender, EventArgs e)
        {
            var myForm = new DisplayClock();
            myForm.Show();
        }

        private void b_drink_Click(object sender, EventArgs e)
        {
            var myForm = new WhatToDrink();
            myForm.Show();
        }

        private void b_luckydraw_Click(object sender, EventArgs e)
        {
            var myForm = new Luckydraw();
            myForm.Show();
        }

        private void b_fortune_Click(object sender, EventArgs e)
        {
            var myForm = new fortunestick();
            myForm.Show();
        }

        private void b_digitalcandle_Click(object sender, EventArgs e)
        {
            var myForm = new digitalcandle();
            myForm.Show();
        }

        private void b_clickcounter_Click(object sender, EventArgs e)
        {
            var myForm = new clickcounter();
            myForm.Show();
        }

        private void b_lootboxSim_Click(object sender, EventArgs e)
        {
            var myForm = new lootboxSim();
            myForm.Show();
        }

        private void b_guess_Click(object sender, EventArgs e)
        {
            var myForm = new GuessNum();
            myForm.Show();
        }
    }
}
