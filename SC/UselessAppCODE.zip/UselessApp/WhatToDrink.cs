﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class WhatToDrink : Form
    {

        string randomresult;

        public WhatToDrink()
        {
            InitializeComponent();
        }

        private void b_WTD_Click(object sender, EventArgs e)
        {

            string[] dlist = {"Tea","Milk","Water","Coffee","fruit juice","vegitable juice","hot chocolate",
                            "soft drinks", "sprkling water", "bubble tea", "Go eat something"};
            randomresult = dlist[new Random().Next(0, dlist.Length)];
            WTD_show.Text = randomresult;
        }
    }
}
