﻿
namespace UselessApp
{
    partial class WhatToDrink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_WTD = new System.Windows.Forms.Button();
            this.WTD_title = new System.Windows.Forms.Label();
            this.WTD_show = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // b_WTD
            // 
            this.b_WTD.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_WTD.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b_WTD.Location = new System.Drawing.Point(244, 375);
            this.b_WTD.Name = "b_WTD";
            this.b_WTD.Size = new System.Drawing.Size(236, 55);
            this.b_WTD.TabIndex = 0;
            this.b_WTD.Text = "choose for me!";
            this.b_WTD.UseVisualStyleBackColor = true;
            this.b_WTD.Click += new System.EventHandler(this.b_WTD_Click);
            // 
            // WTD_title
            // 
            this.WTD_title.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WTD_title.AutoSize = true;
            this.WTD_title.Font = new System.Drawing.Font("Microsoft JhengHei UI", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WTD_title.Location = new System.Drawing.Point(152, 57);
            this.WTD_title.Name = "WTD_title";
            this.WTD_title.Size = new System.Drawing.Size(456, 77);
            this.WTD_title.TabIndex = 1;
            this.WTD_title.Text = "What to Drink?";
            // 
            // WTD_show
            // 
            this.WTD_show.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WTD_show.AutoSize = true;
            this.WTD_show.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WTD_show.ForeColor = System.Drawing.Color.Blue;
            this.WTD_show.Location = new System.Drawing.Point(219, 226);
            this.WTD_show.Name = "WTD_show";
            this.WTD_show.Size = new System.Drawing.Size(298, 38);
            this.WTD_show.TabIndex = 2;
            this.WTD_show.Text = "See your result here";
            this.WTD_show.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WhatToDrink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 481);
            this.Controls.Add(this.WTD_show);
            this.Controls.Add(this.WTD_title);
            this.Controls.Add(this.b_WTD);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "WhatToDrink";
            this.Text = "What To Drink";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b_WTD;
        private System.Windows.Forms.Label WTD_title;
        private System.Windows.Forms.Label WTD_show;
    }
}