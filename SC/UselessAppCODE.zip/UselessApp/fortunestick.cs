﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class fortunestick : Form
    {
        string randomresult;
        public fortunestick()
        {
            InitializeComponent();
        }

        private void b_fortunestick_Click(object sender, EventArgs e)
        {
            string[] fslist = {"吉","大吉","凶","大凶","平"};
            randomresult = fslist[new Random().Next(0, fslist.Length)];
            fs_result.Text = randomresult;
        }
    }
}
