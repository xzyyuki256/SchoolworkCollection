﻿
namespace UselessApp
{
    partial class GuessNum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tipslb = new System.Windows.Forms.Label();
            this.Userinputans = new System.Windows.Forms.TextBox();
            this.b_submit = new System.Windows.Forms.Button();
            this.anslb = new System.Windows.Forms.Label();
            this.StartGamepnl = new System.Windows.Forms.Panel();
            this.sttext = new System.Windows.Forms.Label();
            this.b_Start = new System.Windows.Forms.Button();
            this.StartGamepnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tipslb
            // 
            this.Tipslb.AutoSize = true;
            this.Tipslb.Font = new System.Drawing.Font("Microsoft JhengHei UI", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Tipslb.Location = new System.Drawing.Point(93, 90);
            this.Tipslb.Name = "Tipslb";
            this.Tipslb.Size = new System.Drawing.Size(302, 102);
            this.Tipslb.TabIndex = 0;
            this.Tipslb.Text = "1 - 100";
            this.Tipslb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Userinputans
            // 
            this.Userinputans.Location = new System.Drawing.Point(185, 287);
            this.Userinputans.Name = "Userinputans";
            this.Userinputans.Size = new System.Drawing.Size(87, 27);
            this.Userinputans.TabIndex = 1;
            // 
            // b_submit
            // 
            this.b_submit.Location = new System.Drawing.Point(278, 287);
            this.b_submit.Name = "b_submit";
            this.b_submit.Size = new System.Drawing.Size(94, 29);
            this.b_submit.TabIndex = 2;
            this.b_submit.Text = "submit";
            this.b_submit.UseVisualStyleBackColor = true;
            this.b_submit.Click += new System.EventHandler(this.b_submit_Click);
            // 
            // anslb
            // 
            this.anslb.AutoSize = true;
            this.anslb.Location = new System.Drawing.Point(120, 290);
            this.anslb.Name = "anslb";
            this.anslb.Size = new System.Drawing.Size(59, 19);
            this.anslb.TabIndex = 3;
            this.anslb.Text = "answer";
            // 
            // StartGamepnl
            // 
            this.StartGamepnl.BackColor = System.Drawing.Color.MistyRose;
            this.StartGamepnl.Controls.Add(this.sttext);
            this.StartGamepnl.Controls.Add(this.b_Start);
            this.StartGamepnl.Location = new System.Drawing.Point(54, 63);
            this.StartGamepnl.Name = "StartGamepnl";
            this.StartGamepnl.Size = new System.Drawing.Size(359, 291);
            this.StartGamepnl.TabIndex = 4;
            this.StartGamepnl.Visible = false;
            this.StartGamepnl.VisibleChanged += new System.EventHandler(this.StartGamepnl_VisibleChanged);
            // 
            // sttext
            // 
            this.sttext.AutoSize = true;
            this.sttext.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sttext.Location = new System.Drawing.Point(39, 104);
            this.sttext.Name = "sttext";
            this.sttext.Size = new System.Drawing.Size(290, 38);
            this.sttext.TabIndex = 1;
            this.sttext.Text = "Guess the Number!";
            // 
            // b_Start
            // 
            this.b_Start.Location = new System.Drawing.Point(118, 167);
            this.b_Start.Name = "b_Start";
            this.b_Start.Size = new System.Drawing.Size(115, 42);
            this.b_Start.TabIndex = 0;
            this.b_Start.Text = "Start";
            this.b_Start.UseVisualStyleBackColor = true;
            this.b_Start.Click += new System.EventHandler(this.b_Start_Click);
            // 
            // GuessNum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 422);
            this.Controls.Add(this.StartGamepnl);
            this.Controls.Add(this.anslb);
            this.Controls.Add(this.b_submit);
            this.Controls.Add(this.Userinputans);
            this.Controls.Add(this.Tipslb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "GuessNum";
            this.Text = "GuessNum";
            this.StartGamepnl.ResumeLayout(false);
            this.StartGamepnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Tipslb;
        private System.Windows.Forms.TextBox Userinputans;
        private System.Windows.Forms.Button b_submit;
        private System.Windows.Forms.Label anslb;
        private System.Windows.Forms.Panel StartGamepnl;
        private System.Windows.Forms.Label sttext;
        private System.Windows.Forms.Button b_Start;
    }
}