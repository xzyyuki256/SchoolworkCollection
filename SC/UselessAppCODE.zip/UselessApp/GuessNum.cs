﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class GuessNum : Form
    {

        int ans;
        string userans;
        bool startnewgame = true;
        int tipmin = 1;
        int tipmax = 100;

        public GuessNum()
        {
            InitializeComponent();
            StartGamepnl.Visible = true;
        }

        private void StartGamepnl_VisibleChanged(object sender, EventArgs e)
        {
            //generate answer when starting new game
            while (startnewgame == true)
            {
                Random random = new Random();
                ans = random.Next(1, 101);
                break;
            }
        }

        private void b_Start_Click(object sender, EventArgs e)
        {
            StartGamepnl.Visible = false;
            startnewgame = false;
            Tipslb.Text = "1" + " - " + "100";
        }

        private void b_submit_Click(object sender, EventArgs e)
        {
            userans = Userinputans.Text;

            if (int.TryParse(userans, out int value))
            {
                int intans = Convert.ToInt32(userans);

                if(intans == ans)
                {
                    MessageBox.Show("You are correct!", "Win");
                    StartGamepnl.Visible = true;
                    startnewgame = true;
                }
                else 
                {
                    if (ans > intans && intans <= tipmax && intans >= tipmin)
                    {
                        tipmin = intans;
                    }
                    else if(ans < intans && intans <= tipmax && intans >= tipmin)
                    {
                        tipmax = intans;
                    }
                    else
                    {
                        MessageBox.Show("Invalid value, please enter a integer between the range shows above");
                    }

                    MessageBox.Show("Try again", "Not correct");
                    Tipslb.Text = Convert.ToString(tipmin) + " - " + Convert.ToString(tipmax);


                }
            }
            else 
            {
                MessageBox.Show("Invalid value, please enter a integer between the range shows above");
            }
        }
    }
}
