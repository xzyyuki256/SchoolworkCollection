﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class lootboxSim : Form
    {

        int coins = 500;
        string randomresult;
        int N = 30;
        int R = 70;
        int SR = 150;
        int SSR = 500;
        int SP = 300;

        public lootboxSim()
        {
            InitializeComponent();

            lbcoins.Text = "Coins: " + coins;

        }

        private void b_unbox_Click(object sender, EventArgs e)
        {

            // probability
            string[] lclist = { "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N",
                                "R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "R",
                                "SR", "SR", "SR", "SR", "SR", "SR",
                                "SSR",
                                "SP", "SP", "SP",
                                "Empty box", "Empty box", "Empty box", "Empty box", "Empty box", "Empty box", "Empty box", "Empty box","Empty box","Empty box",
                                "Empty box","Empty box","Empty box","Empty box","Empty box","Empty box","Empty box","Empty box","Empty box","Empty box"};


            // you can open the box only if you have enough money
            if (coins >= 50)
            {
                randomresult = lclist[new Random().Next(0, lclist.Length)];

                coins -= 50;
                confirmWindow.Visible = true;
                ShowResult.Text = randomresult + " * 1";

                // result -> money
                if (randomresult == "N")
                {
                    coins += N;
                }
                else if (randomresult == "R")
                {
                    coins += R;
                }
                else if (randomresult == "SR")
                {
                    coins += SR;
                }
                else if (randomresult == "SSR")
                {
                    coins += SSR;
                }
                else if (randomresult == "SP")
                {
                    coins += SP;
                }

                lbcoins.Text = "Coins: " + Convert.ToString(coins);
            }
            else
            {

                MessageBox.Show("Sorry, you don't have enough money. Game Over.", "End");
            }
        }

        private void b_close_Click(object sender, EventArgs e)
        {
            confirmWindow.Visible = false;
        }
    }
}
