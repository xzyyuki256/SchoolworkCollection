﻿
namespace UselessApp
{
    partial class digitalcandle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.thincandle = new System.Windows.Forms.Label();
            this.fatcandle = new System.Windows.Forms.Label();
            this.tealight = new System.Windows.Forms.Label();
            this.b_lightcandle = new System.Windows.Forms.Button();
            this.ChooseCandle = new System.Windows.Forms.ListBox();
            this.CandleFlame = new System.Windows.Forms.Label();
            this.unlitcandle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // thincandle
            // 
            this.thincandle.BackColor = System.Drawing.Color.White;
            this.thincandle.Location = new System.Drawing.Point(192, 216);
            this.thincandle.Name = "thincandle";
            this.thincandle.Size = new System.Drawing.Size(64, 240);
            this.thincandle.TabIndex = 0;
            this.thincandle.Visible = false;
            // 
            // fatcandle
            // 
            this.fatcandle.BackColor = System.Drawing.Color.Red;
            this.fatcandle.Location = new System.Drawing.Point(122, 216);
            this.fatcandle.Name = "fatcandle";
            this.fatcandle.Size = new System.Drawing.Size(208, 240);
            this.fatcandle.TabIndex = 1;
            this.fatcandle.Visible = false;
            // 
            // tealight
            // 
            this.tealight.BackColor = System.Drawing.Color.Orange;
            this.tealight.Location = new System.Drawing.Point(122, 351);
            this.tealight.Name = "tealight";
            this.tealight.Size = new System.Drawing.Size(208, 105);
            this.tealight.TabIndex = 2;
            this.tealight.Visible = false;
            // 
            // b_lightcandle
            // 
            this.b_lightcandle.Location = new System.Drawing.Point(12, 12);
            this.b_lightcandle.Name = "b_lightcandle";
            this.b_lightcandle.Size = new System.Drawing.Size(94, 29);
            this.b_lightcandle.TabIndex = 3;
            this.b_lightcandle.Text = "light";
            this.b_lightcandle.UseVisualStyleBackColor = true;
            this.b_lightcandle.Click += new System.EventHandler(this.b_lightcandle_Click);
            // 
            // ChooseCandle
            // 
            this.ChooseCandle.FormattingEnabled = true;
            this.ChooseCandle.ItemHeight = 19;
            this.ChooseCandle.Items.AddRange(new object[] {
            "thin candle",
            "fat candle",
            "tealight candle"});
            this.ChooseCandle.Location = new System.Drawing.Point(303, 12);
            this.ChooseCandle.Name = "ChooseCandle";
            this.ChooseCandle.Size = new System.Drawing.Size(126, 23);
            this.ChooseCandle.TabIndex = 4;
            this.ChooseCandle.SelectedIndexChanged += new System.EventHandler(this.ChooseCandle_SelectedIndexChanged);
            // 
            // CandleFlame
            // 
            this.CandleFlame.AutoSize = true;
            this.CandleFlame.Font = new System.Drawing.Font("Microsoft JhengHei UI", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CandleFlame.ForeColor = System.Drawing.Color.DarkOrange;
            this.CandleFlame.Location = new System.Drawing.Point(165, 114);
            this.CandleFlame.Name = "CandleFlame";
            this.CandleFlame.Size = new System.Drawing.Size(125, 102);
            this.CandleFlame.TabIndex = 5;
            this.CandleFlame.Text = "🔥";
            this.CandleFlame.Visible = false;
            // 
            // unlitcandle
            // 
            this.unlitcandle.Location = new System.Drawing.Point(12, 12);
            this.unlitcandle.Name = "unlitcandle";
            this.unlitcandle.Size = new System.Drawing.Size(94, 29);
            this.unlitcandle.TabIndex = 6;
            this.unlitcandle.Text = "unlit";
            this.unlitcandle.UseVisualStyleBackColor = true;
            this.unlitcandle.Visible = false;
            this.unlitcandle.Click += new System.EventHandler(this.unlitcandle_Click);
            // 
            // digitalcandle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(441, 449);
            this.Controls.Add(this.CandleFlame);
            this.Controls.Add(this.ChooseCandle);
            this.Controls.Add(this.b_lightcandle);
            this.Controls.Add(this.tealight);
            this.Controls.Add(this.thincandle);
            this.Controls.Add(this.fatcandle);
            this.Controls.Add(this.unlitcandle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "digitalcandle";
            this.Text = "digitalcandle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label thincandle;
        private System.Windows.Forms.Label fatcandle;
        private System.Windows.Forms.Label tealight;
        private System.Windows.Forms.Button b_lightcandle;
        private System.Windows.Forms.ListBox ChooseCandle;
        private System.Windows.Forms.Label CandleFlame;
        private System.Windows.Forms.Button unlitcandle;
    }
}