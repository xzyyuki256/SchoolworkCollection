﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class clickcounter : Form
    {
        int count = 0;
        bool cheatmode = false;

        public clickcounter()
        {
            InitializeComponent();
        }

        private void b_click_Click(object sender, EventArgs e)
        {
            
            if (cheatmode == true)
            {
                count = count + 10;
            }
            else
            {
                count = count + 1;
            }

            number.Text = Convert.ToString(count);
        }

        private void b_clear_Click(object sender, EventArgs e)
        {
            count = 0;
            number.Text = Convert.ToString(count);
            cheatmode = false;
            cheatcodetext.Text = "cheat Off";
        }

        private void cheatcodetext_Click(object sender, EventArgs e)
        {
            cheatmode = true;
            cheatcodetext.Text = "cheat On";


        }
    }
}
