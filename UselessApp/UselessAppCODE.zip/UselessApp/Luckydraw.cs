﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class Luckydraw : Form
    {
        string randomresult;

        public Luckydraw()
        {
            InitializeComponent();
        }

        private void b_Number_Click(object sender, EventArgs e)
        {
            /*
            int nummin;
            int nummax;
            string innum; 

            nummin = Convert.ToInt32(LDn_min.Text);
            nummax = Convert.ToInt32(LDn_max.Text);

            int[] numlist = new int[nummax+1];

            for (int i = nummin; i < nummax + 1; i++)
            {
                numlist[i] = i;
            }

            innum = Convert.ToString(numlist);
            InputTextbox.Text = innum;
            */
            MessageBox.Show("Function under maintainance!", "Error");
        }

        private void b_ldstart_Click(object sender, EventArgs e)
        {
            string[] rlist = InputTextbox.Text.Split(new Char[] { '\n' });
            randomresult = rlist[new Random().Next(0, rlist.Length)];
            LDresult.Text = randomresult;
        }

        private void Luckydraw_Load(object sender, EventArgs e)
        {

        }
    }
}
