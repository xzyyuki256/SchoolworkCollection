﻿
namespace UselessApp
{
    partial class DisplayClock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Clocktime = new System.Windows.Forms.Timer(this.components);
            this.Displaytime = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Clocktime
            // 
            this.Clocktime.Enabled = true;
            this.Clocktime.Interval = 500;
            this.Clocktime.Tick += new System.EventHandler(this.Clocktime_Tick);
            // 
            // Displaytime
            // 
            this.Displaytime.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Displaytime.Font = new System.Drawing.Font("Microsoft JhengHei UI", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Displaytime.Location = new System.Drawing.Point(44, 77);
            this.Displaytime.Name = "Displaytime";
            this.Displaytime.Size = new System.Drawing.Size(703, 275);
            this.Displaytime.TabIndex = 1;
            this.Displaytime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DisplayClock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Displaytime);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "DisplayClock";
            this.Text = "Clock";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer Clocktime;
        private System.Windows.Forms.Label Displaytime;
    }
}