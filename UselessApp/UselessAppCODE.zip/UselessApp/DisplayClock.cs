﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class DisplayClock : Form
    {
        public DisplayClock()
        {
            InitializeComponent();
        }

        private void Clocktime_Tick(object sender, EventArgs e)
        {
            Displaytime.Text = DateTime.Now.TimeOfDay.ToString("hh\\:mm\\:ss");

        }
    }
}
