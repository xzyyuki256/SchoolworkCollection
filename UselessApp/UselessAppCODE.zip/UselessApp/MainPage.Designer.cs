﻿
namespace UselessApp
{
    partial class MainPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tab = new System.Windows.Forms.TabControl();
            this.Tab_tools = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.b_bigclock = new System.Windows.Forms.Button();
            this.b_fortune = new System.Windows.Forms.Button();
            this.b_luckydraw = new System.Windows.Forms.Button();
            this.b_drink = new System.Windows.Forms.Button();
            this.b_digitalcandle = new System.Windows.Forms.Button();
            this.b_clickcounter = new System.Windows.Forms.Button();
            this.Tab_games = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.b_guess = new System.Windows.Forms.Button();
            this.b_lootboxSim = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.b_option = new System.Windows.Forms.Button();
            this.b_about = new System.Windows.Forms.Button();
            this.VersionText = new System.Windows.Forms.Label();
            this.Tab.SuspendLayout();
            this.Tab_tools.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.Tab_games.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab
            // 
            this.Tab.Controls.Add(this.Tab_tools);
            this.Tab.Controls.Add(this.Tab_games);
            this.Tab.Location = new System.Drawing.Point(12, 12);
            this.Tab.Name = "Tab";
            this.Tab.SelectedIndex = 0;
            this.Tab.Size = new System.Drawing.Size(782, 473);
            this.Tab.TabIndex = 0;
            // 
            // Tab_tools
            // 
            this.Tab_tools.Controls.Add(this.tableLayoutPanel1);
            this.Tab_tools.Location = new System.Drawing.Point(4, 28);
            this.Tab_tools.Name = "Tab_tools";
            this.Tab_tools.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_tools.Size = new System.Drawing.Size(774, 441);
            this.Tab_tools.TabIndex = 1;
            this.Tab_tools.Text = "Tools";
            this.Tab_tools.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.button6, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.b_bigclock, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.b_fortune, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.b_luckydraw, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.b_drink, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.b_digitalcandle, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.b_clickcounter, 2, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 22);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(789, 264);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.Location = new System.Drawing.Point(3, 201);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(256, 60);
            this.button6.TabIndex = 9;
            this.button6.Text = "WIP";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.Location = new System.Drawing.Point(3, 135);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(256, 60);
            this.button5.TabIndex = 8;
            this.button5.Text = "WIP";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.Location = new System.Drawing.Point(265, 135);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(257, 60);
            this.button4.TabIndex = 7;
            this.button4.Text = "WIP";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(528, 135);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(258, 60);
            this.button3.TabIndex = 6;
            this.button3.Text = "WIP";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // b_bigclock
            // 
            this.b_bigclock.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_bigclock.Location = new System.Drawing.Point(265, 69);
            this.b_bigclock.Name = "b_bigclock";
            this.b_bigclock.Size = new System.Drawing.Size(257, 60);
            this.b_bigclock.TabIndex = 4;
            this.b_bigclock.Text = "Display Clock";
            this.b_bigclock.UseVisualStyleBackColor = true;
            this.b_bigclock.Click += new System.EventHandler(this.b_bigclock_Click);
            // 
            // b_fortune
            // 
            this.b_fortune.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_fortune.Location = new System.Drawing.Point(3, 69);
            this.b_fortune.Name = "b_fortune";
            this.b_fortune.Size = new System.Drawing.Size(256, 60);
            this.b_fortune.TabIndex = 3;
            this.b_fortune.Text = "Fortune Stick";
            this.b_fortune.UseVisualStyleBackColor = true;
            this.b_fortune.Click += new System.EventHandler(this.b_fortune_Click);
            // 
            // b_luckydraw
            // 
            this.b_luckydraw.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_luckydraw.Location = new System.Drawing.Point(528, 3);
            this.b_luckydraw.Name = "b_luckydraw";
            this.b_luckydraw.Size = new System.Drawing.Size(258, 60);
            this.b_luckydraw.TabIndex = 2;
            this.b_luckydraw.Text = "Lucky Draw";
            this.b_luckydraw.UseVisualStyleBackColor = true;
            this.b_luckydraw.Click += new System.EventHandler(this.b_luckydraw_Click);
            // 
            // b_drink
            // 
            this.b_drink.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_drink.Location = new System.Drawing.Point(265, 3);
            this.b_drink.Name = "b_drink";
            this.b_drink.Size = new System.Drawing.Size(257, 60);
            this.b_drink.TabIndex = 1;
            this.b_drink.Text = "What to drink";
            this.b_drink.UseVisualStyleBackColor = true;
            this.b_drink.Click += new System.EventHandler(this.b_drink_Click);
            // 
            // b_digitalcandle
            // 
            this.b_digitalcandle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_digitalcandle.Location = new System.Drawing.Point(3, 3);
            this.b_digitalcandle.Name = "b_digitalcandle";
            this.b_digitalcandle.Size = new System.Drawing.Size(256, 60);
            this.b_digitalcandle.TabIndex = 0;
            this.b_digitalcandle.Text = "Digital Candle";
            this.b_digitalcandle.UseVisualStyleBackColor = true;
            this.b_digitalcandle.Click += new System.EventHandler(this.b_digitalcandle_Click);
            // 
            // b_clickcounter
            // 
            this.b_clickcounter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_clickcounter.Location = new System.Drawing.Point(528, 69);
            this.b_clickcounter.Name = "b_clickcounter";
            this.b_clickcounter.Size = new System.Drawing.Size(258, 60);
            this.b_clickcounter.TabIndex = 5;
            this.b_clickcounter.Text = "click counter";
            this.b_clickcounter.UseVisualStyleBackColor = true;
            this.b_clickcounter.Click += new System.EventHandler(this.b_clickcounter_Click);
            // 
            // Tab_games
            // 
            this.Tab_games.Controls.Add(this.tableLayoutPanel3);
            this.Tab_games.Location = new System.Drawing.Point(4, 28);
            this.Tab_games.Name = "Tab_games";
            this.Tab_games.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_games.Size = new System.Drawing.Size(774, 441);
            this.Tab_games.TabIndex = 0;
            this.Tab_games.Text = "Game";
            this.Tab_games.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.b_guess, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.b_lootboxSim, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(16, 22);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(741, 378);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // b_guess
            // 
            this.b_guess.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_guess.Location = new System.Drawing.Point(250, 3);
            this.b_guess.Name = "b_guess";
            this.b_guess.Size = new System.Drawing.Size(241, 60);
            this.b_guess.TabIndex = 1;
            this.b_guess.Text = "Guess the Number";
            this.b_guess.UseVisualStyleBackColor = true;
            this.b_guess.Click += new System.EventHandler(this.b_guess_Click);
            // 
            // b_lootboxSim
            // 
            this.b_lootboxSim.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_lootboxSim.Location = new System.Drawing.Point(3, 3);
            this.b_lootboxSim.Name = "b_lootboxSim";
            this.b_lootboxSim.Size = new System.Drawing.Size(241, 60);
            this.b_lootboxSim.TabIndex = 0;
            this.b_lootboxSim.Text = "Loot Box Simulator";
            this.b_lootboxSim.UseVisualStyleBackColor = true;
            this.b_lootboxSim.Click += new System.EventHandler(this.b_lootboxSim_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(69, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 94);
            this.button1.TabIndex = 4;
            this.button1.Text = "Display Clock";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 94);
            this.button2.TabIndex = 3;
            this.button2.Text = "Fortune Stick";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.button1, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // b_option
            // 
            this.b_option.Location = new System.Drawing.Point(696, 491);
            this.b_option.Name = "b_option";
            this.b_option.Size = new System.Drawing.Size(94, 29);
            this.b_option.TabIndex = 1;
            this.b_option.Text = "Options";
            this.b_option.UseVisualStyleBackColor = true;
            this.b_option.Click += new System.EventHandler(this.b_option_Click);
            // 
            // b_about
            // 
            this.b_about.Location = new System.Drawing.Point(16, 491);
            this.b_about.Name = "b_about";
            this.b_about.Size = new System.Drawing.Size(94, 29);
            this.b_about.TabIndex = 2;
            this.b_about.Text = "About";
            this.b_about.UseVisualStyleBackColor = true;
            this.b_about.Click += new System.EventHandler(this.b_about_Click);
            // 
            // VersionText
            // 
            this.VersionText.AutoSize = true;
            this.VersionText.Location = new System.Drawing.Point(348, 496);
            this.VersionText.Name = "VersionText";
            this.VersionText.Size = new System.Drawing.Size(103, 19);
            this.VersionText.TabIndex = 3;
            this.VersionText.Text = "Version 0.0.1 ";
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 532);
            this.Controls.Add(this.VersionText);
            this.Controls.Add(this.b_about);
            this.Controls.Add(this.b_option);
            this.Controls.Add(this.Tab);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainPage";
            this.Text = "Useless Menu";
            this.Tab.ResumeLayout(false);
            this.Tab_tools.ResumeLayout(false);
            this.Tab_tools.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.Tab_games.ResumeLayout(false);
            this.Tab_games.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl Tab;
        private System.Windows.Forms.TabPage Tab_tools;
        private System.Windows.Forms.TabPage Tab_games;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button b_bigclock;
        private System.Windows.Forms.Button b_fortune;
        private System.Windows.Forms.Button b_luckydraw;
        private System.Windows.Forms.Button b_drink;
        private System.Windows.Forms.Button b_digitalcandle;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button b_guess;
        private System.Windows.Forms.Button b_lootboxSim;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button b_option;
        private System.Windows.Forms.Button b_about;
        private System.Windows.Forms.Label VersionText;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button b_clickcounter;
    }
}

