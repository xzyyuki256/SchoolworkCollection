﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UselessApp
{
    public partial class digitalcandle : Form
    {

        public digitalcandle()
        {
            InitializeComponent();
        }

        private void b_lightcandle_Click(object sender, EventArgs e)
        {
            b_lightcandle.Visible = false;
            unlitcandle.Visible = true;
            CandleFlame.Visible = true;
        }

        private void unlitcandle_Click(object sender, EventArgs e)
        {
            b_lightcandle.Visible = true;
            unlitcandle.Visible = false;
            CandleFlame.Visible = false;
        }
        private void ChooseCandle_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem = ChooseCandle.SelectedItem.ToString();
            switch(curItem)
            {
                case "thin candle":
                    CandleFlame.Visible = false;
                    fatcandle.Visible = false;
                    thincandle.Visible = true;
                    tealight.Visible = false;
                    break;

                case "fat candle":
                    CandleFlame.Visible = false;
                    fatcandle.Visible = true;
                    thincandle.Visible = false;
                    tealight.Visible = false;
                    break;

                case "tealight candle":
                    CandleFlame.Visible = false;
                    fatcandle.Visible = false;
                    thincandle.Visible = false;
                    tealight.Visible = true;
                    break;
            }
        }


    }
}
