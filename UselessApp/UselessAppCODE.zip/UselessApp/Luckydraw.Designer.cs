﻿
namespace UselessApp
{
    partial class Luckydraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_ldstart = new System.Windows.Forms.Button();
            this.InputTextbox = new System.Windows.Forms.TextBox();
            this.b_Number = new System.Windows.Forms.Button();
            this.LDtextlabel = new System.Windows.Forms.Label();
            this.LDresult = new System.Windows.Forms.Label();
            this.LDn_min = new System.Windows.Forms.TextBox();
            this.LDn_max = new System.Windows.Forms.TextBox();
            this.limitlabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // b_ldstart
            // 
            this.b_ldstart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_ldstart.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b_ldstart.Location = new System.Drawing.Point(464, 308);
            this.b_ldstart.Name = "b_ldstart";
            this.b_ldstart.Size = new System.Drawing.Size(143, 60);
            this.b_ldstart.TabIndex = 0;
            this.b_ldstart.Text = "Start";
            this.b_ldstart.UseVisualStyleBackColor = true;
            this.b_ldstart.Click += new System.EventHandler(this.b_ldstart_Click);
            // 
            // InputTextbox
            // 
            this.InputTextbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InputTextbox.Location = new System.Drawing.Point(27, 28);
            this.InputTextbox.Multiline = true;
            this.InputTextbox.Name = "InputTextbox";
            this.InputTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InputTextbox.Size = new System.Drawing.Size(308, 550);
            this.InputTextbox.TabIndex = 1;
            this.InputTextbox.Text = "1 line = 1 item\r\nplease enter";
            // 
            // b_Number
            // 
            this.b_Number.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.b_Number.Location = new System.Drawing.Point(367, 518);
            this.b_Number.Name = "b_Number";
            this.b_Number.Size = new System.Drawing.Size(136, 60);
            this.b_Number.TabIndex = 2;
            this.b_Number.Text = "Input Number";
            this.b_Number.UseVisualStyleBackColor = true;
            this.b_Number.Click += new System.EventHandler(this.b_Number_Click);
            // 
            // LDtextlabel
            // 
            this.LDtextlabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LDtextlabel.AutoSize = true;
            this.LDtextlabel.Font = new System.Drawing.Font("Microsoft JhengHei UI", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LDtextlabel.Location = new System.Drawing.Point(399, 60);
            this.LDtextlabel.Name = "LDtextlabel";
            this.LDtextlabel.Size = new System.Drawing.Size(292, 102);
            this.LDtextlabel.TabIndex = 3;
            this.LDtextlabel.Text = "Result:";
            // 
            // LDresult
            // 
            this.LDresult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LDresult.AutoSize = true;
            this.LDresult.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LDresult.ForeColor = System.Drawing.Color.Blue;
            this.LDresult.Location = new System.Drawing.Point(448, 207);
            this.LDresult.Name = "LDresult";
            this.LDresult.Size = new System.Drawing.Size(176, 42);
            this.LDresult.TabIndex = 4;
            this.LDresult.Text = "Press start";
            this.LDresult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LDn_min
            // 
            this.LDn_min.Location = new System.Drawing.Point(523, 551);
            this.LDn_min.Name = "LDn_min";
            this.LDn_min.Size = new System.Drawing.Size(84, 27);
            this.LDn_min.TabIndex = 5;
            this.LDn_min.Text = "0";
            // 
            // LDn_max
            // 
            this.LDn_max.Location = new System.Drawing.Point(632, 551);
            this.LDn_max.Name = "LDn_max";
            this.LDn_max.Size = new System.Drawing.Size(84, 27);
            this.LDn_max.TabIndex = 6;
            this.LDn_max.Text = "100";
            // 
            // limitlabel
            // 
            this.limitlabel.AutoSize = true;
            this.limitlabel.Font = new System.Drawing.Font("Microsoft JhengHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.limitlabel.Location = new System.Drawing.Point(609, 549);
            this.limitlabel.Name = "limitlabel";
            this.limitlabel.Size = new System.Drawing.Size(23, 29);
            this.limitlabel.TabIndex = 7;
            this.limitlabel.Text = "-";
            // 
            // Luckydraw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 602);
            this.Controls.Add(this.limitlabel);
            this.Controls.Add(this.LDn_max);
            this.Controls.Add(this.LDn_min);
            this.Controls.Add(this.LDresult);
            this.Controls.Add(this.LDtextlabel);
            this.Controls.Add(this.b_Number);
            this.Controls.Add(this.InputTextbox);
            this.Controls.Add(this.b_ldstart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Luckydraw";
            this.RightToLeftLayout = true;
            this.Text = "Lucky Draw";
            this.Load += new System.EventHandler(this.Luckydraw_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b_ldstart;
        private System.Windows.Forms.TextBox InputTextbox;
        private System.Windows.Forms.Button b_Number;
        private System.Windows.Forms.Label LDtextlabel;
        private System.Windows.Forms.Label LDresult;
        private System.Windows.Forms.TextBox LDn_min;
        private System.Windows.Forms.TextBox LDn_max;
        private System.Windows.Forms.Label limitlabel;
    }
}