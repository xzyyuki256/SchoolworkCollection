﻿
namespace UselessApp
{
    partial class clickcounter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_click = new System.Windows.Forms.Button();
            this.CC_text = new System.Windows.Forms.Label();
            this.number = new System.Windows.Forms.Label();
            this.b_clear = new System.Windows.Forms.Button();
            this.cheatcodetext = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // b_click
            // 
            this.b_click.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b_click.Location = new System.Drawing.Point(143, 272);
            this.b_click.Name = "b_click";
            this.b_click.Size = new System.Drawing.Size(114, 50);
            this.b_click.TabIndex = 0;
            this.b_click.Text = "Click";
            this.b_click.UseVisualStyleBackColor = true;
            this.b_click.Click += new System.EventHandler(this.b_click_Click);
            // 
            // CC_text
            // 
            this.CC_text.AutoSize = true;
            this.CC_text.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CC_text.Location = new System.Drawing.Point(143, 57);
            this.CC_text.Name = "CC_text";
            this.CC_text.Size = new System.Drawing.Size(121, 42);
            this.CC_text.TabIndex = 1;
            this.CC_text.Text = "Count:";
            // 
            // number
            // 
            this.number.AutoSize = true;
            this.number.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.number.Location = new System.Drawing.Point(181, 138);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(37, 42);
            this.number.TabIndex = 2;
            this.number.Text = "0";
            this.number.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // b_clear
            // 
            this.b_clear.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b_clear.Location = new System.Drawing.Point(143, 346);
            this.b_clear.Name = "b_clear";
            this.b_clear.Size = new System.Drawing.Size(114, 50);
            this.b_clear.TabIndex = 3;
            this.b_clear.Text = "Clear";
            this.b_clear.UseVisualStyleBackColor = true;
            this.b_clear.Click += new System.EventHandler(this.b_clear_Click);
            // 
            // cheatcodetext
            // 
            this.cheatcodetext.AutoSize = true;
            this.cheatcodetext.Location = new System.Drawing.Point(328, 393);
            this.cheatcodetext.Name = "cheatcodetext";
            this.cheatcodetext.Size = new System.Drawing.Size(72, 19);
            this.cheatcodetext.TabIndex = 4;
            this.cheatcodetext.Text = "cheat Off";
            this.cheatcodetext.Click += new System.EventHandler(this.cheatcodetext_Click);
            // 
            // clickcounter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 421);
            this.Controls.Add(this.cheatcodetext);
            this.Controls.Add(this.b_clear);
            this.Controls.Add(this.number);
            this.Controls.Add(this.CC_text);
            this.Controls.Add(this.b_click);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "clickcounter";
            this.Text = "click counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b_click;
        private System.Windows.Forms.Label CC_text;
        private System.Windows.Forms.Label number;
        private System.Windows.Forms.Button b_clear;
        private System.Windows.Forms.Label cheatcodetext;
    }
}