﻿
namespace UselessApp
{
    partial class lootboxSim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Boxu = new System.Windows.Forms.Button();
            this.b_unbox = new System.Windows.Forms.Button();
            this.lbcoins = new System.Windows.Forms.Label();
            this.confirmWindow = new System.Windows.Forms.Panel();
            this.Resulttext = new System.Windows.Forms.Label();
            this.ShowResult = new System.Windows.Forms.Label();
            this.b_close = new System.Windows.Forms.Button();
            this.confirmWindow.SuspendLayout();
            this.SuspendLayout();
            // 
            // Boxu
            // 
            this.Boxu.BackColor = System.Drawing.Color.Black;
            this.Boxu.Enabled = false;
            this.Boxu.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Boxu.ForeColor = System.Drawing.Color.White;
            this.Boxu.Location = new System.Drawing.Point(274, 90);
            this.Boxu.Name = "Boxu";
            this.Boxu.Size = new System.Drawing.Size(180, 163);
            this.Boxu.TabIndex = 0;
            this.Boxu.Text = "Loot Crates";
            this.Boxu.UseVisualStyleBackColor = false;
            // 
            // b_unbox
            // 
            this.b_unbox.Location = new System.Drawing.Point(274, 340);
            this.b_unbox.Name = "b_unbox";
            this.b_unbox.Size = new System.Drawing.Size(163, 50);
            this.b_unbox.TabIndex = 1;
            this.b_unbox.Text = "Open (-50)";
            this.b_unbox.UseVisualStyleBackColor = true;
            this.b_unbox.Click += new System.EventHandler(this.b_unbox_Click);
            // 
            // lbcoins
            // 
            this.lbcoins.AutoSize = true;
            this.lbcoins.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbcoins.Location = new System.Drawing.Point(12, 22);
            this.lbcoins.Name = "lbcoins";
            this.lbcoins.Size = new System.Drawing.Size(128, 38);
            this.lbcoins.TabIndex = 2;
            this.lbcoins.Text = "Coins: 0";
            // 
            // confirmWindow
            // 
            this.confirmWindow.BackColor = System.Drawing.Color.MistyRose;
            this.confirmWindow.Controls.Add(this.b_close);
            this.confirmWindow.Controls.Add(this.ShowResult);
            this.confirmWindow.Controls.Add(this.Resulttext);
            this.confirmWindow.Location = new System.Drawing.Point(136, 80);
            this.confirmWindow.Name = "confirmWindow";
            this.confirmWindow.Size = new System.Drawing.Size(466, 338);
            this.confirmWindow.TabIndex = 3;
            this.confirmWindow.Visible = false;
            // 
            // Resulttext
            // 
            this.Resulttext.AutoSize = true;
            this.Resulttext.Font = new System.Drawing.Font("Microsoft JhengHei UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Resulttext.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Resulttext.Location = new System.Drawing.Point(138, 42);
            this.Resulttext.Name = "Resulttext";
            this.Resulttext.Size = new System.Drawing.Size(171, 60);
            this.Resulttext.TabIndex = 0;
            this.Resulttext.Text = "Result:";
            // 
            // ShowResult
            // 
            this.ShowResult.AutoSize = true;
            this.ShowResult.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ShowResult.Location = new System.Drawing.Point(172, 154);
            this.ShowResult.Name = "ShowResult";
            this.ShowResult.Size = new System.Drawing.Size(0, 43);
            this.ShowResult.TabIndex = 1;
            // 
            // b_close
            // 
            this.b_close.Location = new System.Drawing.Point(172, 276);
            this.b_close.Name = "b_close";
            this.b_close.Size = new System.Drawing.Size(94, 29);
            this.b_close.TabIndex = 2;
            this.b_close.Text = "Close";
            this.b_close.UseVisualStyleBackColor = true;
            this.b_close.Click += new System.EventHandler(this.b_close_Click);
            // 
            // lootboxSim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 504);
            this.Controls.Add(this.confirmWindow);
            this.Controls.Add(this.lbcoins);
            this.Controls.Add(this.Boxu);
            this.Controls.Add(this.b_unbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "lootboxSim";
            this.Text = "Loot box Simulator";
            this.confirmWindow.ResumeLayout(false);
            this.confirmWindow.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Boxu;
        private System.Windows.Forms.Button b_unbox;
        private System.Windows.Forms.Label lbcoins;
        private System.Windows.Forms.Panel confirmWindow;
        private System.Windows.Forms.Label ShowResult;
        private System.Windows.Forms.Label Resulttext;
        private System.Windows.Forms.Button b_close;
    }
}